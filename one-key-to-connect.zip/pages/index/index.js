//index.js
//获取应用实例
const app = getApp()
import Notify from '../../dist/notify/notify';
Page({
  data: {
    localIp: '',
    wifiName: '',
    wifiPw: '',
    activeNames: ['1'],
    wifissid: 'HelpHero',
    wifiCon: '',
    steps: [{
        text: '步骤一',
        desc: '点击"连接热点"'
      }, {
        text: '步骤二',
        desc: '输入IP'
      },
      {
        text: '步骤三',
        desc: '输入账号，密码'
      },
      {
        text: '步骤四',
        desc: '点击"开始配网"'
      }
    ]
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function() {

  },
  freshIp: function() {
    let that = this
    const a = wx.createUDPSocket()
    const localPort = a.bind()
    console.log(this.data.localIp)
    const sendMsga = '{"login":"yes","ssid":"' + this.data.wifiName + '","password":"' + this.data.wifiPw + '"}'
    a.send({
      address: that.data.localIp,
      port: 7788,
      message: sendMsga
    })
    a.onError(function(res) {
      console.log(res)
    })
    console.log('以发送')
  },
  a8266Ip: function(res) {
    this.setData({
      localIp: res.detail
    })
  },
  wifiName: function(res) {
    this.setData({
      wifiName: res.detail
    })
  },
  wifiPw: function(res) {
    this.setData({
      wifiPw: res.detail
    })
  },
  shoufengqin: function(res) {
    this.setData({
      activeNames: res.detail
    });
  },
  getIp: function(res) {
    let that = this
    wx.startWifi({
      success: that.conWifi,
      fail: console.log
    })
  },
  conWifi:function(){
    wx.connectWifi({
      SSID:'HelpHero',
      password:'123456789',
      success: Notify({ type: 'primary', message: '连接热点成功，请查看IP后开始配网' }),
      fail: Notify({ type: 'danger', message: '连接热点失败，请重试或手动连接' })
    })
  }
})